#include "_header.h"

int main()
{
    ///Variables
    int sommet, fin, fin2, menu=1;
    int x=0;
    int condition=0;
    std::vector<int> previous;
    std::vector<Avion*> a;
    Carte g{"avions.txt"};
        Carte c("Aeroport.txt");


    c.init_allegro();
    c.ini_bitmap();
    for(int i=0; i<=28 ; i++)
    line(c.get_bitmapp("Map"),368,302+(i*15),368+(15*63),302+(i*15),makecol(100,100,100));
    for(int i=0; i<=63 ; i++)
    line(c.get_bitmapp("Map"),368+(i*15),302,368+(i*15),302+(28*15),makecol(100,100,100));


    blit(c.get_bitmapp("Map"), c.get_bitmapp("buffer"), 0,0,0,0,ecran_x, ecran_y);

    blit(c.get_bitmapp("buffer"), screen , 0, 0, 0, 0, ecran_x, ecran_y);


    while (menu == 1)
    {

        ///appel de la classe Carte (graphe)

        a=g.getAvion();

        std::vector<int> poids((int)c.getSo().size(),-1);

        /// appel de la m�thode pour afficher le graphe
        c.afficher1();
        g.afficher();

        ///saisie du num�ro du sommet initial pour lancer un Dijkstra
        std::cout<<std::endl<<"numero du sommet initial : ";
        std::cin >> sommet;
        ///Blindage
        while (sommet < 0 || sommet > c.get_ordre1()-1 )
        {
            std::cout << "Erreur lors de la saisis !" << std::endl;
            std::cin >> sommet;
        }

        std::cout<<std::endl<<"numero du sommet final : ";
        std::cin >>fin;
        ///Blindage
        while (fin < 0 || fin > c.get_ordre1()-1 )
        {
            std::cout << "Erreur lors de la saisis !" << std::endl;
            std::cin >> fin;
        }
        std::cout<<std::endl;

        int num;
        while (num < 1 || num > g.get_ordre() )
        {
            std::cout<<std::endl<<"saisir un avion : ";
            std::cin>>num;

        }

          ///Dijkstra + affichage
              std::cout<<std::endl;
              previous=c.Dijkstra(sommet,fin,num,poids,a,&condition);
              std::cout <<std::endl;
              aff(sommet,fin,previous,poids);

     if(condition==1)
     {
         std::cout << "L'avion ne peut decoller car pas assez de carburant" << std::endl;
     }

       /// On parcourt tous les poids du chemin
    /*    for(int i=0;i<previous.size();i++)
        {
            ///si la consommation par rapport � la distance est sup � la capacit�
            if((a[num-1]->getConso()*(poids[i]/100))>(a[num-1]->getCapacite()))
          {
             std::cout<<std::endl<<"Pas assez de carburant!";
          }
        }*/



    ///CALCUL AVEC A STAR

    Aeroport* sommet_actu;
    pair<int,int> case_dep;
    pair<int,int> case_arr;

    //RECUP LES COO DANS CASE DEPART
    sommet_actu = c.getSo_i(sommet);
    case_dep.first = sommet_actu->get_x();
    case_dep.second = sommet_actu->get_y();

    //RECUP LES COO DANS CASE ARRIVE
    sommet_actu = c.getSo_i(fin);
    case_arr.first = sommet_actu->get_x();
    case_arr.second = sommet_actu->get_y();

    Trajet trajet;
    std::vector < pair<int,int> > PCC;
    ///LE QUADRILLAGE EST DE <0,0> � <61,29>
    PCC = trajet.AStar(case_dep,case_arr);
    for(int i=0; i<PCC.size(); i++)
        std::cout<< "(" << PCC[i].first << "," << PCC[i].second << ")" << std::endl;

    ///AFFICHAGE SUR ALLEGRO


        std::cout <<std::endl;

        std::cout << "Voulez vous quitter le programme: 1. NON  2. OUI" << std::endl;
        std::cin >> menu;

        ///Blindage
        while(menu > 2 || menu <1)
        {
            std::cout << "Erreur lors de la saisis !" << std::endl;
            std::cin >> menu;
        }

        ///Arret pgrm
        if (menu == 2)
        {
            return 0;
        }
        std::cout << std::endl;
        system("cls");
    }

}END_OF_MAIN()
