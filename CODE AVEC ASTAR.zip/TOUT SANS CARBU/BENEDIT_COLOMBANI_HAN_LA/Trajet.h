#ifndef TRAJET_H_INCLUDED
#define TRAJET_H_INCLUDED

class Trajet
{
private:

    bool vol;
    std::vector <Case*> m_carte;


public:

    Trajet() {};
    ~Trajet() {};

    ///Sous programme Astar qui va retourner un vecteur de pair ( les coo que l'avion fera)
    std::vector < pair<int,int> > AStar( pair<int,int> coo_dep, pair<int,int> coo_arr);
    float GetDistance(Case* Coo_dep, Case* Coo_arr);
};















#endif // TRAJET_H_INCLUDED
