#ifndef AVION_H_INCLUDED
#define AVION_H_INCLUDED

class Avion
{

private :

    std::string m_type;
    int m_conso;
    int m_capacite;

public :
    /*constructeur*/
    Avion(std::string type, int conso, int capacite):m_type(type),m_conso(conso),m_capacite(capacite) {};
    /*accesseurs*/
    std::string getType()const
    {
        return m_type;
    }
    void setType(std::string type)
    {
        m_type=type;
    }

    void setConso(int conso)
    {
        m_conso=conso;
    }
    int getConso() const
    {
        return m_conso;
    }
    void setCapacite(int capacite)
    {
        m_capacite=capacite;
    }
    int getCapacite() const
    {
        return m_capacite;
    }
    void aff()
    {
        std::cout << "Type d'avion: " << getType() << " courrier" << "  |  consommation: "<< getConso() <<" L/100km"<< "  |  capacite carburant: " << getCapacite() <<" L" << std::endl;
    }
};

#endif // AVION_H_INCLUDED
