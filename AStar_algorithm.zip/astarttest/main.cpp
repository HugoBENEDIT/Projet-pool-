#include <iostream>
#include <map>
#include <vector>
#include <fstream>
#include <utility>
#include <math.h>
#include <limits>   // Mettre la valeur "infinie"         std::numeric_limits<int>::max()

using namespace std;




class Case
{
private:
    int m_x,m_y;
    int m_id;
    float m_G;
    float m_H;

public:

    Case();
    Case(int x, int y,int id, float G, float H);
    ~Case();
    ///====================

    int getX()
    {
        return m_x;
    } const
    int getY()
    {
        return m_y;
    } const
    int getId()
    {
        return m_id;
    } const
    float getG()
    {
        return m_G;
    } const
    float getH()
    {
        return m_H;
    } const

    void setG(float n)
    {
        m_G = n;
    }
    void setH(float n)
    {
        m_H = n;
    }
    void setId(int n)
    {
        m_id = n;
    }

    double getF()
    {
        return m_G + m_H;
    }



};

Case::Case() {}
Case::Case(int x, int y,int id, float G, float H)
    : m_x(x),m_y(y),m_id(id),m_G(G),m_H(H) {}
Case::~Case() {}

float GetDistance(Case* Coo_dep, Case* Coo_arr)
{
    float a = Coo_arr->getX() - Coo_dep->getX();
    float b = Coo_arr->getY() - Coo_dep->getY();

    float a2 = pow(a,2);
    float b2 = pow(b,2);

    float c = sqrt (a2 + b2);

    return c;
}


class Carte
{
private:

    std::vector <Case*> m_carte;


public:
    Carte() {};
    ~Carte() {};

    AStar( pair<int,int> coo_dep, pair<int,int> coo_arr);




};




Carte::AStar( pair<int,int> coo_dep, pair<int,int> coo_arr)
{

    ///BLINDER SI CASE DEP ET CASE ARR SONT SUR LE PLATEAU

    std::vector < pair<int,int> > PCC;

    for(int j=0; j<30; j++)
        for(int i=0; i<62; i++)
            m_carte.push_back(new Case(i,j,1,std::numeric_limits<int>::max(),std::numeric_limits<int>::max()));

    Case *Case_dep;
    Case *Case_arr;
    Case *Case_actu;

    int debut = 1;


    for (auto s : m_carte)  ///INITIALISATION
    {
        if(coo_dep.first == s->getX() && coo_dep.second == s->getY() )
        {
            Case_dep = s;
            Case_actu = s;
        }

        if(coo_arr.first == s->getX() && coo_arr.second == s->getY() )
        {
            Case_arr = s;
        }
    }


    ///INITIALISE LES PREDECESSEURS A FALSE
    std::vector < std::vector <bool>> preds;
    std::vector <bool> tmp_bool;
    for(int i=0; i<62; i++)
        tmp_bool.push_back(true);
    for(int i=0; i<30; i++)
        preds.push_back(tmp_bool);

    preds[coo_dep.second][coo_dep.first]=false;

    while(Case_actu->getX() != coo_arr.first && Case_actu->getY() != coo_arr.second)
    {


    Case *CaseNO;
    Case *CaseN;
    Case *CaseNE;
    Case *CaseE;
    Case *CaseSE;
    Case *CaseS;
    Case *CaseSO;
    Case *CaseO;


        for (auto s : m_carte) ///Boucle for permettant de passer par les cases et trouver les cases voisin de la case actuelle
        {

            if(s->getX() == Case_actu->getX()-1 && s->getY() == Case_actu->getY()-1 && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseNO = s;

            }

            if(s->getX() == Case_actu->getX() && s->getY() == Case_actu->getY()-1  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseN = s;
            }

            if(s->getX() == Case_actu->getX()+1 && s->getY() == Case_actu->getY()-1  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseNE = s;
            }

            if(s->getX() == Case_actu->getX()+1 && s->getY() == Case_actu->getY()  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseE = s;
            }

            if(s->getX() == Case_actu->getX()+1 && s->getY() == Case_actu->getY()+1  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseSE = s;
            }

            if(s->getX() == Case_actu->getX() && s->getY() == Case_actu->getY()+1  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseS = s;
            }

            if(s->getX() == Case_actu->getX()-1 && s->getY() == Case_actu->getY()+1  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseSO = s;
            }

            if(s->getX() == Case_actu->getX()-1 && s->getY() == Case_actu->getY()  && s->getId() == 1)
            {

                s->setG(GetDistance(s,Case_dep));
                s->setH(GetDistance(s,Case_arr));
                s->setId(0);
                CaseO = s;
            }
        }

        std::cout << "TEST " << std::endl;

        if(preds[CaseNO->getY()][CaseNO->getX()]==false)
            CaseNO->setG(100);

        if(preds[CaseN->getY()][CaseN->getX()]==false)
            CaseN->setG(100);

        if(preds[CaseNE->getY()][CaseNE->getX()]==false)
            CaseNE->setG(100);

        if(preds[CaseE->getY()][CaseE->getX()]==false)
            CaseE->setG(100);

        if(preds[CaseSE->getY()][CaseSE->getX()]==false)
            CaseSE->setG(100);

        if(preds[CaseS->getY()][CaseS->getX()]==false)
            CaseS->setG(100);

        if(preds[CaseSO->getY()][CaseSO->getX()]==false)
            CaseSO->setG(100);

        if(preds[CaseO->getY()][CaseO->getX()]==false)
            CaseO->setG(100);


        std::vector<float> F_comparaison;
        F_comparaison.push_back(CaseNO->getF());
        F_comparaison.push_back(CaseN->getF());
        F_comparaison.push_back(CaseNE->getF());
        F_comparaison.push_back(CaseE->getF());
        F_comparaison.push_back(CaseSE->getF());
        F_comparaison.push_back(CaseS->getF());
        F_comparaison.push_back(CaseSO->getF());
        F_comparaison.push_back(CaseO->getF());

        for(int i=0; i<F_comparaison.size(); i++)
        {
            std::cout << F_comparaison[i] << std::endl;
        }

        int petit=-1;
        float num_min = std::numeric_limits<int>::max();
        for(int i=0; i<F_comparaison.size(); i++) //Compare alors toutes les valeurs du tableau afin de r�cuperer le plus petit F
        {
            if(F_comparaison[i]<num_min)
            {

                num_min=F_comparaison[i];
                petit = i;

            }
        }

        preds[Case_actu->getY()][Case_actu->getX()]=false;

        if(petit == 0)
        {
            std::cout << "IL VA EN NO " << std::endl;
            Case_actu= CaseNO;
        }

        if(petit == 1)
        {
            std::cout << "IL VA EN CaseN " << std::endl;
            Case_actu= CaseN;
        }
        if(petit == 2)
        {
            std::cout << "IL VA EN CaseNE " << std::endl;
            Case_actu= CaseNE;
        }
        if(petit == 3)
        {
            std::cout << "IL VA EN CaseE " << std::endl;
            Case_actu= CaseE;
        }
        if(petit == 4)
        {
            std::cout << "IL VA EN CaseSE " << std::endl;
            Case_actu= CaseSE;
        }
        if(petit == 5)
        {
            std::cout << "IL VA EN CaseS " << std::endl;
            Case_actu= CaseS;
        }
        if(petit == 6)
        {
            std::cout << "IL VA EN CaseSO " << std::endl;
            Case_actu= CaseSO;
        }
        if(petit == 7)
        {
            std::cout << "IL VA EN CaseO " << std::endl;
            Case_actu= CaseO;
        }



        pair<int,int> tmp;
        tmp.first= Case_actu->getX();
        tmp.second = Case_actu->getY();

        PCC.push_back(tmp);



        ///FIN DE LA BOUCLE
    }

    for(int i=0; i<PCC.size(); i++)
        std::cout<< "(" << PCC[i].first << "," << PCC[i].second << ")" << std::endl;





}

int main()
{

    Carte carte;


    ///Mettre blindage pour savoir si les cases sont dans le plateau
    pair<int,int> case_dep = make_pair(45,2);
    pair<int,int> case_arr = make_pair(2,21);

    carte.AStar(case_dep,case_arr);

}
