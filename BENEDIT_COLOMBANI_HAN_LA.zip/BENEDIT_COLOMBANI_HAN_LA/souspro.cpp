#include "_header.h"

///---------------------------------------------------------------------------------

///on envoie en parametre le sommet initial et le vecteur des pr�d�cesseurs
void aff(size_t num,size_t fin,const std::vector<int>& graph,const std::vector<int>& p)
{
    size_t i,j,x;
    int poids_tot=0;

    ///on parcours notre vector des pr�d�cesseurs
    for(i=0; i<graph.size();i++)
    {
        ///si l'it�rateur est diff�rent du sommet initial
        if(i!=num && i==fin)
        {
            ///et si le pr�d�cesseur a bien �t� marqu� (car -1 il n'est pas marqu�)
            if(graph[i]!=-1)
            {
                x=p[i];
                poids_tot+=x;

                std::cout<<"[P:"<<x<<"]";
                std::cout<<i<<" <- ";

                j=graph[i];


                while(j!=num)
                {
                    x=p[j];
                    poids_tot+=x;
                    std::cout<<"[P:"<<x<<"]";
                    std::cout<<j<<" <- ";
                    j=graph[j];

                }

                std::cout<<j<<std::endl;
            }
        }
    }
    std::cout<<"Poids total: "<<poids_tot<<std::endl;
}

void delay(unsigned int mseconds)
{
    clock_t goal = mseconds + clock();
    while (goal > clock());
}
