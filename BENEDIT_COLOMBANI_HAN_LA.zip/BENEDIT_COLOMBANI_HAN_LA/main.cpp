#include "_header.h"

int main()
{
    ///Variables
    int sommet, fin, fin2, menu=1;
    int x=0;
    int condition=0;
    std::vector<int> previous;
    std::vector<Avion*> a;
    Carte g{"avions.txt"};
    Carte c("Aeroport.txt");
    /*
    c.init_allegro();
    c.ini_bitmap();
    BITMAP* buffer = create_bitmap(ecran_x, ecran_y);
    blit(c.get_bitmapp("Map"), buffer, 0,0,0,0,ecran_x, ecran_y);
    blit(buffer, screen , 0, 0, 0, 0, ecran_x, ecran_y);
    */
    while (menu == 1)
    {
        ///appel de la classe Carte (graphe)

        a=g.getAvion();

        std::vector<int> poids((int)c.getSo().size(),-1);

        /// appel de la m�thode pour afficher le graphe
        c.afficher1();
        g.afficher();

        ///saisie du num�ro du sommet initial pour lancer un Dijkstra
        std::cout<<std::endl<<"numero du sommet initial : ";
        std::cin >> sommet;
        ///Blindage
        while (sommet < 0 || sommet > c.get_ordre1()-1 )
        {
            std::cout << "Erreur lors de la saisis !" << std::endl;
            std::cin >> sommet;
        }

        std::cout<<std::endl<<"numero du sommet final : ";
        std::cin >>fin;
        ///Blindage
        while (fin < 0 || fin > c.get_ordre1()-1 )
        {
            std::cout << "Erreur lors de la saisis !" << std::endl;
            std::cin >> fin;
        }
        std::cout<<std::endl;

        int num;
        while (num < 1 || num > g.get_ordre() )
        {
            std::cout<<std::endl<<"saisir un avion : ";
            std::cin>>num;

        }

          ///Dijkstra + affichage
              std::cout<<std::endl;
              previous=c.Dijkstra(sommet,fin,num,poids,a,&condition);
              std::cout <<std::endl;
              aff(sommet,fin,previous,poids);

     if(condition==1)
     {
         std::cout << "L'avion ne peut decoller car pas assez de carburant" << std::endl;
     }

       /// On parcourt tous les poids du chemin
    /*    for(int i=0;i<previous.size();i++)
        {
            ///si la consommation par rapport � la distance est sup � la capacit�
            if((a[num-1]->getConso()*(poids[i]/100))>(a[num-1]->getCapacite()))
          {
             std::cout<<std::endl<<"Pas assez de carburant!";
          }
        }*/


        std::cout <<std::endl;

        std::cout << "Voulez vous quitter le programme: 1. NON  2. OUI" << std::endl;
        std::cin >> menu;

        ///Blindage
        while(menu > 2 || menu <1)
        {
            std::cout << "Erreur lors de la saisis !" << std::endl;
            std::cin >> menu;
        }

        ///Arret pgrm
        if (menu == 2)
        {
            return 0;
        }
        std::cout << std::endl;
        system("cls");
    }

}END_OF_MAIN()
