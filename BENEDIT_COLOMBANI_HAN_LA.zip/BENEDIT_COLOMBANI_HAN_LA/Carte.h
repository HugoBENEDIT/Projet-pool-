#ifndef CARTE_H_INCLUDED
#define CARTE_H_INCLUDED

class Carte
{
private :
    ///liste des sommets (vecteur de pointeurs sur Sommet)

    std::vector<Aeroport*> m_aeroport;
    std::vector<Avion*> m_avions;
    std::vector<int> m_nb_arete;
    std::map <string, BITMAP*> m_bitmap;


    ///nb sommets
    int m_ordre;
    int m_ordre1;
    ///nb arretes
    int m_taille;

public :

    Carte(std::string nomFichier)
    {
        if(nomFichier == "Aeroport.txt")
        {
            std::ifstream ifs{nomFichier};
            std::ifstream ifs2{"Aretes.txt"};
            if (!ifs)
                throw std::runtime_error( "Impossible d'ouvrir en lecture " + nomFichier );
            if (!ifs2)
                throw std::runtime_error( "Impossible d'ouvrir en lecture Aretes.txt");
            ifs >> m_ordre1;
            for(int i=0; i<m_ordre1; i++)
            {
                std::string prenom;
                int nom, x, y, pistes, places, delai, temps, anticollision, decat, duree, nb_aretes;
                ifs >> nom >> prenom;
                ifs >> x >> y >> pistes >> places >> delai >> temps >> anticollision >> decat >> duree >> nb_aretes;
                if ( ifs.fail() )
                    throw std::runtime_error("Probleme lecture de l'aeroport");
                Aeroport* a= new Aeroport(nom, prenom, x, y, pistes, places, delai, temps, anticollision, decat, duree);
                m_aeroport.push_back(a);
                m_nb_arete.push_back(nb_aretes);
            }
            for(int i=0; i<m_ordre1; i++)
            {
                for(int j=0; j< m_nb_arete[i]; j++)
                {
                    int nom2, distance;
                    ifs2 >> nom2 >> distance;
                    if ( ifs2.fail() )
                        throw std::runtime_error("Probleme lecture des aretes");
                    m_aeroport[i]->ajouterSucc(m_aeroport[nom2], distance);
                }
            }

        }
        else if (nomFichier == "avions.txt")
        {

            std::ifstream ifs{nomFichier};
            if (!ifs)
                throw std::runtime_error( "Impossible d'ouvrir en lecture " + nomFichier );

            ifs >> m_ordre;
            if ( ifs.fail() )
                throw std::runtime_error("Probleme lecture ordre du graphe");

            ifs >> m_taille;
            if ( ifs.fail() )
                throw std::runtime_error("Probleme lecture taille du graphe");

            // for (int i=0; i< get_ordre()+1 ; ++i)
            //m_sommets.push_back( new Sommet{i, i} );
            string type;
            int conso,capacite;
            for (int i=0; i < m_ordre ; ++i)
            {
                ifs>>type>>conso>>capacite;
                if ( ifs.fail() )
                    throw std::runtime_error("Probleme lecture arc");
                Avion* a= new Avion(type, conso, capacite);
                m_avions.push_back(a);
            }
        }
    }
    /*destructeur*/
    ~Carte()
    {
        for (auto s : m_aeroport)
            delete s;
        for (auto c: m_avions)
            delete c;
    }
    /*m�thode d'affichage*/
    void afficher1() const
    {
        std::cout<<std::endl<<"Carte ";
        std::cout<<std::endl <<"Nombre aeroport : "<< m_ordre1<<std::endl;
        std::cout << "Aeroport :" << std::endl;
        for (int i=0; i < m_aeroport.size(); ++i)
        {
            m_aeroport[i]->aff();
        }
    }
    /*m�thode d'affichage*/
    void afficher() const
    {
        std::cout<<std::endl<<"Carte ";
        std::cout << std::endl <<"Sommets du graph: " << std::endl;
        for (int i=1; i<m_ordre+1; i++)
        {
            std::cout << i << "\t";
        }
        std::cout<<std::endl <<"ordre = "<< m_ordre<<std::endl;
        std::cout<<"taille = "<<m_taille<<std::endl;
        std::cout << "Avions :" << std::endl;
        for (int i=0; i < m_avions.size(); ++i)
        {
            m_avions[i]->aff();
        }
    }

    int get_ordre()
    {
        return m_ordre;
    }

    int get_ordre1()
    {
        return m_ordre1;
    }

    std::vector<Avion*> getAvion()
    {
        return m_avions;
    }

    std::vector<Aeroport*> getSo()const
    {
        return m_aeroport;
    }

    void init_allegro();
    void ini_bitmap();
    void add_bitmap(BITMAP* tmp, std::string s);
    BITMAP* get_bitmapp(std::string c);
    void aff_bit(int i,BITMAP*buffer);

    std::vector <int> Dijkstra(int num,int num2,int num3,std::vector<int>&poids,std::vector<Avion*> a,int* condition) const;

    void parcours(std::vector<int>&poids,std::vector<int>&previous,int num,int num3,std::vector<Avion*> a) const;
};



#endif // CARTE_H_INCLUDED
