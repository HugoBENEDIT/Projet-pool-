#ifndef AEROPORT_H_INCLUDED
#define AEROPORT_H_INCLUDED

class Aeroport
{
private:
    int m_nom;
    std::string m_prenom;
    int m_x;
    int m_y;
    int m_nb_piste;
    int m_nb_places_sol;
    int m_delai_attente_sol;
    int m_temps_acces_pistes;
    int m_delai_anticollision;
    int m_temps_DECAT;
    int m_duree_boucle;
    int m_marque = -1;
    int m_p = -1;
    std::map<const Aeroport*, int> m_distance1;
    std::vector<std::pair<const Aeroport*, int>>m_distance;

public:
    Aeroport(int nom, std::string prenom, int x, int y, int pistes, int places, int delai, int temps, int anticollision, int decat, int duree):m_nom(nom),m_prenom(prenom), m_x(x), m_y(y), m_nb_piste(pistes), m_nb_places_sol(places), m_delai_attente_sol(delai), m_temps_acces_pistes(temps), m_delai_anticollision(anticollision), m_temps_DECAT(decat), m_duree_boucle(duree){};

    ///Getter
    int get_nom() const
    {
        return m_nom;
    }
    std::string get_prenom() const
    {
        return m_prenom;
    }
    int get_x () const
    {
        return m_x;
    }
    int get_y () const
    {
        return m_y;
    }
    int get_pistes() const
    {
        return m_nb_piste;
    }
    int get_places() const
    {
        return m_nb_places_sol;
    }
    int get_delai() const
    {
        return m_delai_attente_sol;
    }
    int get_temps() const
    {
        return m_temps_acces_pistes;
    }
    int get_anticollision() const
    {
        return m_delai_anticollision;
    }
    int get_decat() const
    {
        return m_temps_DECAT;
    }
    int get_duree() const
    {
        return m_duree_boucle;
    }
    const std::vector<std::pair<const Aeroport*, int>>& getSuccesseurs()const {return m_distance;}
    void ajouterSucc(const Aeroport*s, int m_p)
    {
        std::pair<const Aeroport*, int> Suc;
        Suc.first=s;
        Suc.second=m_p;
        m_distance.push_back(Suc);
        m_distance1[s]=m_p;
    }

    void setMarque(int marque){m_marque=marque;}
    int getMarque() const{return m_marque;}
    void setP(int p)
    {
         if(m_p>p || m_p==-1) m_p=p;
        //std::cout << "TEST" << std::endl;
    }
    int getP() const{return m_p;}

    void aff()
    {
        std::cout << "Numero de l'aeroport : " << m_nom << std::endl;
        std::cout << "Nom de l'aeroport : " << m_prenom << std::endl;
        std::cout << "Position de l'aeroport : [" << m_x << "] [" << m_y << "]" << std::endl;
        std::cout << "Nombre de pistes : " << m_nb_piste << std::endl;
        std::cout << "Nombre de places au sol : " << m_nb_places_sol << std::endl;
        std::cout << "Delai attente au sol : " << m_delai_attente_sol << std::endl;
        std::cout << "Temps d'acces aux pistes : " << m_temps_acces_pistes << std::endl;
        std::cout << "Delai anticollision : " << m_delai_anticollision << std::endl;
        std::cout << "Temps Decollage/Atterissage : " << m_temps_DECAT << std::endl;
        std::cout << "Duree boucle d'attente : " << m_duree_boucle << std::endl;
        std::cout << "TEST : " << m_p << std::endl;
        for (std::map<const Aeroport*, int>::iterator it=m_distance1.begin(); it!=m_distance1.end(); ++it)
                std::cout<< "Aeroport : " << m_prenom << " vers " <<it->first->get_prenom() <<" distance ==> " << it->second << std::endl;
        std::cout << std::endl << std::endl;
    }
};


#endif // AEROPORT_H_INCLUDED

