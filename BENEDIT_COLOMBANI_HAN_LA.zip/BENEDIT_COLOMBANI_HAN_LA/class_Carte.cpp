#include "_header.h"

void Carte::init_allegro()
{
    allegro_init();

    set_color_depth(desktop_color_depth());

    if((set_gfx_mode(GFX_AUTODETECT_WINDOWED,ecran_x,ecran_y,0,0))!=0)
    {
        allegro_message("Pb de mode graphique") ;
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    install_keyboard();
}

void Carte::add_bitmap(BITMAP* tmp, std::string s)
{
    m_bitmap[s] = tmp;
}

BITMAP* Carte::get_bitmapp(std::string c)
{
    return m_bitmap[c.c_str()];
}

void Carte::ini_bitmap()
{
    add_bitmap(load_bitmap("Photo/Avion_d.bmp",NULL),"AvionD");
    if (!m_bitmap["AvionD"])
    {
        allegro_message( "AvionD introuvable !" );
        exit( EXIT_FAILURE);
    }
    add_bitmap(load_bitmap("Photo/Map.bmp",NULL),"Map");
    if (!m_bitmap["Map"])
    {
        allegro_message( "Map introuvable !" );
        exit( EXIT_FAILURE);
    }
}

///Commande affichage BitMap masked_blit(get_bitmapp("Salle"), buffer, m_x[i-1], m_y[i-1],0, 0, 250, 250);

std::vector <int> Carte::Dijkstra(int num,int num2,int num3,std::vector<int>&poids,std::vector<Avion*> a,int* condition) const
{

   std::vector<int> c((int)m_aeroport.size(),0);
   std::vector<int> p((int)m_aeroport.size(),1);
   ///avant de commencer on initialise les pr�d�cesseurs a -1 car il n'y en a pas
   std::vector<int> previous((int)m_aeroport.size(),-1);
   int x=num,y=num2;

  int i=0;
int maxi=0;

  m_aeroport[num]->setP(0);

  c[num]=1;
int nb=0;
int fin=0;

  ///on va initialiser le marquage des sommets sauf le sommet initial a 5
    for(int i=0; i<m_aeroport[num]->getSuccesseurs().size();i++)
      {

              m_aeroport[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]->setMarque(5);
             // m_aeroport[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]->getP();
              nb++;
      }


  ///tant que le sommet d'arriv� n'a pas �t� marqu� on continue notre boucle
  while(m_aeroport[num2]->getMarque()!=1 && fin==0)
  {

      ///on marque notre sommet initial dans la Blacklist
      m_aeroport[num]->setMarque(0);
       parcours(poids,previous,num,num3,a);
      ///on va mtn observez et comparer le chemin avec le poids le plus petit avec un for parcourant tous les sommets sauf sommet initial (size -1)

    for(int i=0;i<m_aeroport.size()-1;i++)
      {
          int cpt=0,cpt2=0;
          maxi++;

          if(m_aeroport[i]->getMarque()==1 )
          {
              for(int j=i+1;j<m_aeroport.size();j++)
              {

                   if((a[num3-1]->getConso()*(m_aeroport[j]->getP()/100))>(a[num3-1]->getCapacite()))
                {
                   std::cout<<std::endl<<"TEST";
                   m_aeroport[j]->setMarque(3);

                }
               else if((a[num3-1]->getConso()*(m_aeroport[j]->getP()/100))>(a[num3-1]->getCapacite()) && nb==1)
                {
                    //std::cout<<std::endl<<"NOOO";
                }
                else if(maxi==m_aeroport.size()-2 && (a[num3-1]->getConso()*(m_aeroport[maxi]->getP()/100))>(a[num3-1]->getCapacite()))
                {
                    std::cout<<std::endl<<"NOOO";
                    *condition=1;
                    return previous;
                }

                  if(cpt==0)
                  {
                      num=m_aeroport[i]->get_nom();
                  }
                  if(m_aeroport[j]->getMarque()==1 )
                  {
                      cpt++;

                      ///si on trouve un sommet avec un poids plus petit alors on r�cupere le num�ro de ce sommet
                      if(m_aeroport[i]->getP() > m_aeroport[j]->getP() )
                      {

                          num=m_aeroport[j]->get_nom();
                          cpt2++;

                      }
                      else
                      {
                          num=m_aeroport[i]->get_nom();
                      }
                  }
                 /* else if(m_aeroport[j]->getMarque()==3)
                  {

                  }*/
                   ///si la consommation par rapport � la distance est sup � la capacit�

              }
              if(cpt2==0)
              {
                  i=m_aeroport.size();
              }

          }

      }


  }
  std::cout<<"Voici le meilleur chemin pour aller de "<<m_aeroport[x]->get_prenom() <<" a "<<m_aeroport[y]->get_prenom() <<" avec un Poids total de: "<<m_aeroport[num2]->getP()<<std::endl;

     /*   for(int i=0;i<m_aeroport.size()-1;i++)
        {

            ///si la consommation par rapport � la distance est sup � la capacit�
            if((a[num3-1]->getConso()*(poids[i]/100))>(a[num3-1]->getCapacite()))
          {
              std::cout<<std::endl<<"Pas assez de carburant!";
          }
        }*/
   return previous;
}


void Carte::parcours(std::vector<int>&poids,std::vector<int>&previous,int num,int num3,std::vector<Avion*> a) const
{
    ///ici on va parcourir tous les successeurs du Carte � partir du sommet initial donn�
      for(int i=0; i<m_aeroport[num]->getSuccesseurs().size();i++)
      {
          ///si un successeur n'a pas �t� marqu� alors on marque ce sommet et on additionne le poids du chemin
          if(m_aeroport[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]->getMarque()!=0)
          {
              m_aeroport[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]->setMarque(1);
              m_aeroport[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]->setP(m_aeroport[num]->getSuccesseurs()[i].second + m_aeroport[num]->getP());
              previous[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]= m_aeroport[num]->get_nom();
              poids[m_aeroport[num]->getSuccesseurs()[i].first->get_nom()]=m_aeroport[num]->getSuccesseurs()[i].second;
          }

      }
}
